import React from "react";
import { Link } from "react-router-dom";

const style = {
  display: "flex",
  lineHeight: "10px",
  gap: "0",
};

const Board = ({ posts }) => {
  const returnPosts = posts.map((post) => (
    <div key={post.title} className="board">
      <p>{post.id}</p>
      <p>
        <Link to={`/board/${post.id}`}> {post.title} </Link>
        {/* 
          localhost:3000/board/1
          절대주소
        */}
      </p>
    </div>
  ));

  return <div>{returnPosts}</div>;
};

export default Board;
