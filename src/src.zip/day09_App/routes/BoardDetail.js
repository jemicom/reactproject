import React from "react";
import { useParams, useNavigate } from "react-router-dom";

const BoardDetail = ({ posts }) => {
  const { id } = useParams();
  const navigate = useNavigate();

  const findData = posts.find((post) => post.id === id * 1);

  const gotoBack = () => {
    navigate("/board");
  };

  return (
    <div>
      <h3>BoardDetail {id}</h3>
      <div> {findData.id} </div>
      <div> {findData.title} </div>
      <div> {findData.body} </div>
      <div> {findData.datetime} </div>
      <button onClick={gotoBack}>목록보기</button>
    </div>
  );
};

export default BoardDetail;
