import React from "react";

const Home = () => {
  const style = {
    height: "2000px",
    background: "skyblue",
  };
  return <div style={style}>Home</div>;
};

export default Home;
