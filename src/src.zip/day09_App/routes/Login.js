import React, { useState, useRef } from "react";

const INITIAL_STATE = {
  userid: "",
  userpwd: "",
};

const Login = () => {
  const [user, setUser] = useState(INITIAL_STATE);
  const useridRef = useRef();
  const userpwdRef = useRef();
  console.log(useridRef);

  const handleChange = (event) => {
    console.log(event.target.name);
    setUser((prev) => ({ ...prev, [event.target.name]: event.target.value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    //
  };

  // const input = document.querySelector(input[name="userid"])
  // input.focus()
  // input.value = ""
  const handleReset = () => {
    useridRef.current.focus();
  };
  const handleLogin = () => {
    alert(JSON.stringify(user, null, "  "));
    useridRef.current.value = "";
    userpwdRef.current.value = "";
  };
  return (
    <form onSubmit={handleSubmit}>
      <input
        ref={useridRef}
        type="text"
        name="userid"
        placeholder="아이디"
        onChange={handleChange}
      />
      <input
        type="password"
        name="userpwd"
        ref={userpwdRef}
        placeholder="비밀번호"
        onChange={handleChange}
      />
      <button onClick={handleLogin}>로그인</button>
      <button onClick={handleReset}>취소</button>
    </form>
  );
};

export default Login;
