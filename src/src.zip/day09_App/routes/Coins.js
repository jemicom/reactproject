import React from "react";
import CoinDetail from "./CoinDetail";
import { useNavigate } from "react-router-dom";

const Coins = () => {
  const style = {
    height: "2000px",
    background: "lavender",
  };
  const pStyle = {
    cursor: "pointer",
  };

  const navigate = useNavigate();
  const CoinDetailHandle = (param) => {
    navigate(`/coins/${param}`);
  };
  return (
    <section style={style}>
      <p onClick={() => CoinDetailHandle(1)} style={pStyle}>
        CoinDetail1 http://localhost:3000/coins/1
      </p>
      <p onClick={() => CoinDetailHandle(2)} style={pStyle}>
        CoinDetail2 http://localhost:3000/coins/2
      </p>
      <p onClick={() => CoinDetailHandle(3)} style={pStyle}>
        CoinDetail3 http://localhost:3000/coins/3
      </p>
    </section>
  );
};

export default Coins;
