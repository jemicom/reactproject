import React, { useState } from "react";

const INITIAL_STATE = {
  id: 1,
  username: "",
  useremail: "",
  userpwd: "",
};

// INITIAL_STATE.id
// INITIAL_STATE['id'] // 속성이 바뀔때

// const user = {};
// user.name = "홍";
// user["email"] = "이메일";
// alert(JSON.stringify(user));

const Register = () => {
  const [user, setUser] = useState(INITIAL_STATE);
  const [users, setUsers] = useState([]);

  const handleChange = (event) => {
    console.log(event.target.name);
    setUser((prev) => ({ ...prev, [event.target.name]: event.target.value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setUser((prev) => ({ ...prev, id: prev.id + 1 }));
    setUsers((prev) => [...prev, user]);
    alert(JSON.stringify(user, null, "  "));
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        autoFocus
        type="text"
        name="username"
        placeholder="이름"
        onChange={handleChange}
      />
      <input
        type="email"
        name="useremail"
        placeholder="이메일"
        onChange={handleChange}
      />
      <input
        type="password"
        name="userpwd"
        placeholder="비밀번호"
        onChange={handleChange}
      />
      <button>회원가입</button>
    </form>
  );
};

export default Register;
