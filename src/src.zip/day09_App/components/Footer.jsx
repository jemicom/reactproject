import "./Footer.css";

import React from "react";

const Footer = () => {
  return (
    <footer>
      <address> copyRight&amp; {new Date().getFullYear()} </address>
    </footer>
  );
};

export default Footer;
