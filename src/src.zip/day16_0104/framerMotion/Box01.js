import React from "react";
import { motion } from "framer-motion";

const box = {
  width: "200px",
  height: "200px",
  background: "orange",
  opacity: 0,
};

const Box = () => {
  return (
    <motion.div style={box} animate={{ y: 500, x: 500, opacity: 1 }}>
      Box
    </motion.div>
  );
};

export default Box;
