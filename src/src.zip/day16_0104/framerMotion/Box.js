import React, { useState } from "react";
import { motion } from "framer-motion";

const box = {
  width: "200px",
  height: "200px",
  background: "orange",
};

const Box = () => {
  return (
    <motion.div
      style={box}
      initial={{ x: 100, y: 100 }}
      animate={{
        scale: 1,
      }}
      transition={{ duration: 0.5 }}
      whileTap={{ scale: 1.2 }}
    >
      Box
    </motion.div>
  );
};

export default Box;
