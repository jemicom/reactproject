import React, { useState } from "react";
import { motion } from "framer-motion";

const box = {
  width: "200px",
  height: "200px",
  background: "orange",
};

const Box = () => {
  return (
    <motion.div
      style={box}
      initial={{ x: 100, y: 100 }}
      animate={{
        scale: 1,
      }}
      transition={{ duration: 0.5 }}
      whileHover={{ scale: 1.2 }}
      drag
      dragConstraints={{
        right: 20,
        left: -20,
        top: -20,
        bottom: 20,
      }}
    >
      Box
    </motion.div>
  );
};

export default Box;
