import React from "react";
import { motion } from "framer-motion";

const box = {
  width: "200px",
  height: "200px",
  background: "orange",
};

const Box = () => {
  return (
    <motion.div
      style={box}
      initial={{ x: 200, y: 200 }}
      animate={{ rotate: 360, scale: 1.5 }}
      transition={{ duration: 2 }}
    >
      Box
    </motion.div>
  );
};

export default Box;
