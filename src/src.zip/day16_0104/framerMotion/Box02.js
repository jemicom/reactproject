import React from "react";
import { motion } from "framer-motion";

const box = {
  width: "200px",
  height: "200px",
  background: "orange",
};

const Box = () => {
  return (
    <motion.div
      style={box}
      initial={{ opacity: 0, x: 20, y: 0 }}
      animate={{ y: 200, x: 200, opacity: 1 }}
      transition={{ duration: 2 }}
    >
      Box
    </motion.div>
  );
};

export default Box;
