import React, { useState } from "react";
import { motion } from "framer-motion";

const box = {
  width: "200px",
  height: "200px",
  background: "orange",
};

const Box = () => {
  const [isMove, setIsMove] = useState(false);
  const [isRotate, setIsRotate] = useState(false);
  const [isScale, setIsScale] = useState(false);

  const animateHandle = () => {
    setIsMove(!isMove);
    setIsRotate(!isRotate);
  };
  return (
    <motion.div
      style={box}
      animate={{
        x: isMove ? 200 : 0,
        rotate: isRotate ? 360 : 0,
      }}
      transition={{ duration: 2 }}
      onClick={animateHandle}
    >
      Box
    </motion.div>
  );
};

export default Box;
