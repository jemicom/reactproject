import React from "react";
import MyPieChart from "./reChart/MyPieChart";
import MyBarChart from "./reChart/MyBarChart";
import MyLineChart from "./reChart/MyLineChart";
import Box from "./framerMotion/Box";

const App = () => {
  return (
    <div>
      <Box />
      {/* <MyLineChart /> */}
    </div>
  );
};

export default App;
