import React from "react";
import { PieChart, Pie } from "recharts";

const data = [
  { name: "subject", subject: "html", amount: 99 },
  { name: "subject", subject: "css", amount: 30 },
  { name: "subject", subject: "javascript", amount: 20 },
  { name: "subject", subject: "nodejs", amount: 60 },
  { name: "subject", subject: "react", amount: 70 },
];

export default function MyPieChart() {
  return (
    <PieChart width={800} height={800}>
      <Pie
        dataKey="amount"
        startAngle={0}
        endAngle={360}
        data={data}
        cx={400}
        cy={400}
        outerRadius={180}
        fill="#8884d8"
        label
      />
    </PieChart>
  );
}
