import React, { useState } from "react";
import {
  BrowserRouter,
  Routes,
  Route,
  Link,
  NavLink,
  Outlet,
  useParams,
  useNavigate,
} from "react-router-dom";
import NotFound from "./NotFound";

// npm i react-router-dom
// https://reactrouter.com/en/main

const style = {
  listStyle: "none",
  display: "flex",
  gap: "50px",
};

// 주문 페이지 : 장바구니로가기 버튼 -> 장바구니 페이지로 이동
// 장바구니로가기 버튼은 메뉴로 구성되지 않은 링크를 메뉴처럼 사용하고 싶을 때
// Link, button 아무거나 사용할 수 있음

const NavBar = () => {
  return (
    <nav>
      <ul style={style}>
        <li>
          <NavLink to="/">home</NavLink>
        </li>
        <li>
          <NavLink to="about">about</NavLink>
        </li>
        <li>
          <NavLink to="order">주문</NavLink>
        </li>
        <li>
          <NavLink to="products">products</NavLink>
        </li>
        <li>
          <NavLink to="users">users</NavLink>
        </li>
      </ul>
    </nav>
  );
};

// html page : Multi Page Application (MPA)
// react : Single  Page Application (SPA)
const MyRoute = () => {
  return (
    <BrowserRouter>
      <header>
        <NavBar />
      </header>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="users" element={<Users />}>
          <Route path=":userId" element={<UserDetail />} />
        </Route>

        <Route path="order" element={<Order />} />

        <Route path="about" element={<About />} />
        <Route path="products" element={<Products />}>
          <Route index element={<ArrivalProduct />} />
          <Route path="arrival" element={<ArrivalProduct />} />
          {/* localhost:3000/products/arrival  */}
          {/* 슬래시를 사용하면 절대경로로 변경되어 
             localhost:3000/arrival  */}
          <Route path="new" element={<NewProduct />} />
          <Route path="old" element={<OldProduct />} />
          <Route path=":id" element={<ProductDetail />} />
          <Route path="admin" element={<Admin />} />
        </Route>
        {/* 
            <Route path="products/:id" element={<ProductDetail />} />
            <Route path="products/admin" element={<Admin />} /> 
        */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
};

// 한페이지내에서 자유롭게 사용하기 위해서 함수선언
function Home() {
  return (
    <div className="home">
      <h2>Home page</h2>
    </div>
  );
}

function Order() {
  const navigate = useNavigate();
  return (
    <div className="home">
      <h2>Order Page</h2>
      <button onClick={() => navigate("/products/1")}> 주문 </button>
      <button onClick={() => navigate("/")}> 주문 </button>
      <button onClick={() => navigate("/about")}> 주문 </button>
      <button onClick={() => navigate("/users")}> 주문 </button>
    </div>
  );
}
function OrderCart() {
  return (
    <div className="home">
      <h2>장바구니 Page</h2>
      목록 표시
    </div>
  );
}

function Users() {
  return (
    <div className="home">
      <h2>Users page</h2>
      <Outlet />
    </div>
  );
}

function UserDetail() {
  const params = useParams();
  const { userId } = useParams();
  return (
    <div className="home">
      <h2>User Detail page</h2>
      {JSON.stringify(params)}
      {params.userId}
      {userId}
    </div>
  );
}

function About() {
  return (
    <div className="about">
      <h2>About page</h2>
    </div>
  );
}
function Products() {
  return (
    <div className="products">
      <h2>Products page</h2>
      <nav className="subMenu">
        <ul style={style}>
          <li>
            <Link to="arrival">추천상품</Link>
          </li>
          <li>
            <Link to="new">신규 상품</Link>
          </li>
          <li>
            <Link to="old">빈티지 상품</Link>
          </li>
        </ul>
      </nav>
      <Outlet />
    </div>
  );
}

function ProductDetail() {
  return (
    <div className="products">
      <h2>Products Detail</h2>
    </div>
  );
}

function ArrivalProduct() {
  return (
    <div>
      <h2>ArrivalProduct</h2>
    </div>
  );
}
function NewProduct() {
  return (
    <div>
      <h2>NewProduct</h2>
    </div>
  );
}
function OldProduct() {
  return (
    <div>
      <h2>OldProduct</h2>
    </div>
  );
}

function Admin() {
  return (
    <div className="products">
      <h2>Admin Page</h2>
    </div>
  );
}

export default MyRoute;
