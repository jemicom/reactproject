import React, { useState } from "react";
import { BrowserRouter, Routes, Route, Link, NavLink } from "react-router-dom";
import NotFound from "./NotFound";

// npm i react-router-dom
// https://reactrouter.com/en/main

const style = {
  listStyle: "none",
  display: "flex",
  gap: "50px",
};

// const NavBar = () => {
//   const [isActive, setIsActive] = useState(1);
//   return (
//     <nav>
//       <ul style={style}>
//         <li>
//           <Link
//             to="/"
//             className={isActive === 1 ? "active" : ""}
//             onClick={() => setIsActive(1)}
//           >
//             home
//           </Link>
//         </li>
//         <li>
//           <Link
//             to="about"
//             className={isActive === 2 ? "active" : ""}
//             onClick={() => setIsActive(2)}
//           >
//             about
//           </Link>
//         </li>
//         <li>
//           <Link
//             to="products"
//             className={isActive === 3 ? "active" : ""}
//             onClick={() => setIsActive(3)}
//           >
//             products
//           </Link>
//         </li>
//       </ul>
//     </nav>
//   );
// };

// const NavBar = () => {
//   return (
//     <nav>
//       <ul style={style}>
//         <li>
//           <NavLink to="/">home</NavLink>
//           {/* active를 자동으로 설정하는 기능이 있는 컴포넌트 */}
//         </li>
//         <li>
//           <NavLink to="about">about</NavLink>
//         </li>
//         <li>
//           <NavLink to="products">products</NavLink>
//         </li>
//       </ul>
//     </nav>
//   );
// };

const NavBar = () => {
  return (
    <nav>
      <ul style={style}>
        <li>
          <NavLink
            to="/"
            className={({ isActive }) => (isActive ? "blue" : "")}
          >
            home
            {/* 클래스명이 active 아닌 경우 별도로 처리하기  */}
          </NavLink>
        </li>
        <li>
          <NavLink
            to="about"
            className={({ isActive }) => (isActive ? "blue" : "")}
          >
            about
          </NavLink>
        </li>
        <li>
          <NavLink
            to="products"
            className={({ isActive }) => (isActive ? "blue" : "")}
          >
            products
          </NavLink>
        </li>
      </ul>
    </nav>
  );
};

// // 멈춰두기
// const NavBar = () => {
//   return (
//     <nav>
//       <ul style={style}>
//         <li>
//           <NavLink to="/" style={({ isActive }) => (isActive ? "active" : "")}>
//             home
//           </NavLink>
//         </li>
//         <li>
//           <NavLink
//             to="about"
//             style={({ isActive }) => (isActive ? "active" : "")}
//           >
//             about
//           </NavLink>
//         </li>
//         <li>
//           <NavLink
//             to="products"
//             style={({ isActive }) => (isActive ? "active" : "")}
//           >
//             products
//           </NavLink>
//         </li>
//       </ul>
//     </nav>
//   );
// };

// html page : Multi Page Application (MPA)
// react : Single  Page Application (SPA)
const MyRoute = () => {
  return (
    <BrowserRouter>
      <header>
        <NavBar />
      </header>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="about" element={<About />} />
        <Route path="products" element={<Products />} />
        <Route path="products/:id" element={<ProductDetail />} />
        <Route path="products/admin" element={<Admin />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
};

// 한페이지내에서 자유롭게 사용하기 위해서 함수선언
function Home() {
  return (
    <div className="home">
      <h2>Home page</h2>
    </div>
  );
}
function About() {
  return (
    <div className="about">
      <h2>About page</h2>
    </div>
  );
}
function Products() {
  return (
    <div className="products">
      <h2>Products page</h2>
    </div>
  );
}
function ProductDetail() {
  return (
    <div className="products">
      <h2>Products Detail</h2>
    </div>
  );
}
function Admin() {
  return (
    <div className="products">
      <h2>Admin Page</h2>
    </div>
  );
}

export default MyRoute;
