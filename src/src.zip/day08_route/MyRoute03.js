import React, { useState } from "react";
import {
  BrowserRouter,
  Routes,
  Route,
  Link,
  NavLink,
  Outlet,
} from "react-router-dom";
import NotFound from "./NotFound";

// npm i react-router-dom
// https://reactrouter.com/en/main

const style = {
  listStyle: "none",
  display: "flex",
  gap: "50px",
};

// 중첩 라우팅(Nested Route) : 서브메뉴
// route가 단일 태그가 아니라 쌍으로 이루어진 태그
// 쌍으로 이루어진 태그안에 경로를 넣으면 자동으로 경로를 설정
// 슬래시를 사용하면 절대경로로 처리되므로 문제발생할 수 있고
// 모든 경로를 절대처리하면 문제 없음
// index 키워드 : 기본으로 표시되어야 하는 서브페이지를 설정
// Outlet :  wrapper 클래스, 부모컴포넌트가 하위 컴포넌트를 감싼다.
// 리엑트 디자인 패턴  HOC(High Order Component)
// Outlet을 하위로 두고 싶은 위치에 두면 하위메뉴페이지가 표시됨

const NavBar = () => {
  return (
    <nav>
      <ul style={style}>
        <li>
          <NavLink to="/">home</NavLink>
        </li>
        <li>
          <NavLink to="about">about</NavLink>
        </li>
        <li>
          <NavLink to="products">products</NavLink>
        </li>
      </ul>
    </nav>
  );
};

// html page : Multi Page Application (MPA)
// react : Single  Page Application (SPA)
const MyRoute = () => {
  return (
    <BrowserRouter>
      <header>
        <NavBar />
      </header>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="about" element={<About />} />
        <Route path="products" element={<Products />}>
          <Route index element={<ArrivalProduct />} />
          <Route path="arrival" element={<ArrivalProduct />} />
          {/* localhost:3000/products/arrival  */}
          {/* 슬래시를 사용하면 절대경로로 변경되어 
             localhost:3000/arrival  */}
          <Route path="new" element={<NewProduct />} />
          <Route path="old" element={<OldProduct />} />
        </Route>
        <Route path="products/:id" element={<ProductDetail />} />
        <Route path="products/admin" element={<Admin />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
};

// 한페이지내에서 자유롭게 사용하기 위해서 함수선언
function Home() {
  return (
    <div className="home">
      <h2>Home page</h2>
    </div>
  );
}
function About() {
  return (
    <div className="about">
      <h2>About page</h2>
    </div>
  );
}
function Products() {
  return (
    <div className="products">
      <h2>Products page</h2>
      <nav className="subMenu">
        <ul style={style}>
          <li>
            <Link to="arrival">추천상품</Link>
          </li>
          <li>
            <Link to="new">신규 상품</Link>
          </li>
          <li>
            <Link to="old">빈티지 상품</Link>
          </li>
        </ul>
      </nav>
      <Outlet />
    </div>
  );
}
function ArrivalProduct() {
  return (
    <div>
      <h2>ArrivalProduct</h2>
    </div>
  );
}
function NewProduct() {
  return (
    <div>
      <h2>NewProduct</h2>
    </div>
  );
}
function OldProduct() {
  return (
    <div>
      <h2>OldProduct</h2>
    </div>
  );
}
function ProductDetail() {
  return (
    <div className="products">
      <h2>Products Detail</h2>
    </div>
  );
}
function Admin() {
  return (
    <div className="products">
      <h2>Admin Page</h2>
    </div>
  );
}

export default MyRoute;
