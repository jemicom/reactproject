import React from "react";
import MyRoute from "./MyRoute05";
import "./App.css";

const App = () => {
  return (
    <div>
      <MyRoute />
    </div>
  );
};

export default App;
