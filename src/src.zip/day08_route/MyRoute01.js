import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import NotFound from "./NotFound";

// npm i react-router-dom
// https://reactrouter.com/en/main

const NavBar = () => {
  return (
    <nav>
      <ul>
        <li>
          <a href="/">home</a>
        </li>
        <li>
          <a href="about">about</a>
        </li>
        <li>
          <a href="products">products</a>
        </li>
      </ul>
    </nav>
  );
};

// html page : Multi Page Application (MPA)
// react : Single  Page Application (SPA)
const MyRoute = () => {
  return (
    <BrowserRouter>
      <header>
        <NavBar />
      </header>
      {/* 
        localhost:3000
        localhost:3000/about
        localhost:3000/products
        localhost:3000/products/1
        localhost:3000/products/2
        localhost:3000/products/admin

        // 지정되지 않은 모든 경로
        localhost:3000/hello
        localhost:3000/kim

        상대 주소 : relative route / 를 사용하지 않음 
        절대 주소 : absolute route / 를 사용 
        지금은 라우트가 간단해서 절대주소와 상대주소가 같이 동작함
    */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="about" element={<About />} />
        <Route path="products" element={<Products />} />
        <Route path="products/:id" element={<ProductDetail />} />
        <Route path="products/admin" element={<Admin />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
};

// 한페이지내에서 자유롭게 사용하기 위해서 함수선언
function Home() {
  return (
    <div className="home">
      <h2>Home page</h2>
    </div>
  );
}
function About() {
  return (
    <div className="about">
      <h2>About page</h2>
    </div>
  );
}
function Products() {
  return (
    <div className="products">
      <h2>Products page</h2>
    </div>
  );
}
function ProductDetail() {
  return (
    <div className="products">
      <h2>Products Detail</h2>
    </div>
  );
}
function Admin() {
  return (
    <div className="products">
      <h2>Admin Page</h2>
    </div>
  );
}

export default MyRoute;
