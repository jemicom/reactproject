import React, { useState } from "react";
import {
  BrowserRouter,
  Routes,
  Route,
  Link,
  NavLink,
  Outlet,
  useParams,
} from "react-router-dom";
import NotFound from "./NotFound";

// npm i react-router-dom
// https://reactrouter.com/en/main

const style = {
  listStyle: "none",
  display: "flex",
  gap: "50px",
};

// DynamicRoute
// http://localhost:3000/users/1
// <Route path=":userId" element={<UserDetail1 />} />
// http://localhost:3000/users/2
// <Route path=":userId" element={<UserDetail2 />} />
// 10개만되도 컴포넌트 10개 너무 과도한 일
// useParams() 훅을 이용해서 params를 가져오고 + <UserDetail />

const NavBar = () => {
  return (
    <nav>
      <ul style={style}>
        <li>
          <NavLink to="/">home</NavLink>
        </li>
        <li>
          <NavLink to="about">about</NavLink>
        </li>
        <li>
          <NavLink to="products">products</NavLink>
        </li>
        <li>
          <NavLink to="users">users</NavLink>
        </li>
      </ul>
    </nav>
  );
};

// html page : Multi Page Application (MPA)
// react : Single  Page Application (SPA)
const MyRoute = () => {
  return (
    <BrowserRouter>
      <header>
        <NavBar />
      </header>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="users" element={<Users />}>
          <Route path=":userId" element={<UserDetail />} />
          {/* http://localhost:3000/users/1 */}
          <Route path="users/:userId" element={<UserDetail />} />
          {/* http://localhost:3000/users/users/1 */}
        </Route>

        <Route path="about" element={<About />} />
        <Route path="products" element={<Products />}>
          <Route index element={<ArrivalProduct />} />
          <Route path="arrival" element={<ArrivalProduct />} />
          {/* localhost:3000/products/arrival  */}
          {/* 슬래시를 사용하면 절대경로로 변경되어 
             localhost:3000/arrival  */}
          <Route path="new" element={<NewProduct />} />
          <Route path="old" element={<OldProduct />} />
        </Route>
        <Route path="products/:id" element={<ProductDetail />} />
        <Route path="products/admin" element={<Admin />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
};

// 한페이지내에서 자유롭게 사용하기 위해서 함수선언
function Home() {
  return (
    <div className="home">
      <h2>Home page</h2>
    </div>
  );
}
function Users() {
  return (
    <div className="home">
      <h2>Users page</h2>
      <Outlet />
    </div>
  );
}

// localhost:3000/users/1
// localhost:3000/users/2
// localhost:3000/users/3
function UserDetail() {
  const params = useParams();
  const { userId } = useParams();
  return (
    <div className="home">
      <h2>User Detail page</h2>
      {JSON.stringify(params)}
      {params.userId}
      {userId}
    </div>
  );
}

function About() {
  return (
    <div className="about">
      <h2>About page</h2>
    </div>
  );
}
function Products() {
  return (
    <div className="products">
      <h2>Products page</h2>
      <nav className="subMenu">
        <ul style={style}>
          <li>
            <Link to="arrival">추천상품</Link>
          </li>
          <li>
            <Link to="new">신규 상품</Link>
          </li>
          <li>
            <Link to="old">빈티지 상품</Link>
          </li>
        </ul>
      </nav>
      <Outlet />
    </div>
  );
}

function ProductDetail() {
  return (
    <div className="products">
      <h2>Products Detail</h2>
    </div>
  );
}

function ArrivalProduct() {
  return (
    <div>
      <h2>ArrivalProduct</h2>
    </div>
  );
}
function NewProduct() {
  return (
    <div>
      <h2>NewProduct</h2>
    </div>
  );
}
function OldProduct() {
  return (
    <div>
      <h2>OldProduct</h2>
    </div>
  );
}

function Admin() {
  return (
    <div className="products">
      <h2>Admin Page</h2>
    </div>
  );
}

export default MyRoute;
