import React, { useState, createContext, useContext } from "react";
import { SelectContext } from "./SelectContext";

export const ThemeContext = createContext(null); // 공유할 데이타 선언
export const UserNameContext = createContext(""); // 공유할 데이타 선언

const SubApp = () => {
  const [isDark, setIsDark] = useState(false);
  const [user, setUser] = useState("홍길동");

  return (
    <UserNameContext.Provider value={user}>
      <ThemeContext.Provider value={{ isDark, setIsDark }}>
        <div>
          <Page />
        </div>
      </ThemeContext.Provider>
    </UserNameContext.Provider>
  );
};

const Page = () => {
  return (
    <div className="container">
      {/* <Header isDark={isDark} setIsDark={setIsDark} />
      <Section isDark={isDark} />
      <Footer isDark={isDark} /> */}
      <Header />
      <Section />
      <Footer />
    </div>
  );
};

const Header = () => {
  const { isDark, setIsDark } = useContext(ThemeContext); // 사용할때
  // const data= useContext(ThemeContext); // 사용할때
  // console.log(data.isDark, data.setIsDark);
  return (
    <header
      style={{
        background: isDark ? "black" : "white",
        color: isDark ? "white" : "black",
      }}
    >
      <h1>Header</h1>
      <button onClick={() => setIsDark((prev) => !prev)}>darkmode</button>
      {/* <button onClick={() => setIsDark(!isDark)}>darkmode</button> */}
    </header>
  );
};
const Section = () => {
  const { isDark } = useContext(ThemeContext);
  const { select } = useContext(SelectContext);

  return (
    <section
      style={{
        background: isDark ? "black" : "white",
        color: isDark ? "white" : "black",
      }}
    >
      Section
      <p> 좋아하는 과일은 {select}를 선택하셨습니다.</p>
    </section>
  );
};
const Footer = () => {
  const { isDark } = useContext(ThemeContext);
  const user = useContext(UserNameContext);
  console.log(user);
  return (
    <footer
      style={{
        background: isDark ? "black" : "white",
        color: isDark ? "white" : "black",
      }}
    >
      Footer {user ? user : "Guest"}
    </footer>
  );
};

export default SubApp;
