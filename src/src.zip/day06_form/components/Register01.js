import React, { useState } from "react";
import "./Register.css";

const INITIAL_STATE = {
  id: 0,
  username: "",
  useremail: "",
  userpwd: "",
};

const Register = () => {
  const [user, setUser] = useState(INITIAL_STATE);

  const handleChange = (event) => {
    setUser((prev) => ({ ...prev, username: event.target.value }));
  };
  const handleEmailChange = (event) => {
    setUser((prev) => ({ ...prev, useremail: event.target.value }));
  };
  const handlePwdChange = (event) => {
    setUser((prev) => ({ ...prev, userpwd: event.target.value }));
  };

  return (
    <form>
      <input
        type="text"
        name="username"
        placeholder="이름"
        onChange={handleChange}
      />
      <input
        type="email"
        name="useremail"
        placeholder="이메일"
        onChange={handleEmailChange}
      />
      <input
        type="password"
        name="userpwd"
        placeholder="비밀번호"
        onChange={handlePwdChange}
      />
      <button>회원가입</button>
    </form>
  );
};

export default Register;
