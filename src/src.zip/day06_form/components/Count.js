import React, { useState, useRef } from "react";

const Count = () => {
  let [count, setCount] = useState(0); // 화면에 표시 되면서 값을 유지
  let addRef = useRef(0); // 화면에 표시되지 않지만 값을 유지
  console.log(addRef);
  //{current: undefined}
  //{current: 0}
  //{current: '홍길동'}
  let normalCount = 0; // 값을 유지 못함

  const increment = () => {
    setCount((prev) => prev + 1);
  };
  const decrement = () => {
    setCount((prev) => prev - 1);
  };
  const refIncrement = () => {
    addRef.current = addRef.current + 1;
  };
  const refDecrement = () => {
    addRef.current = addRef.current - 1;
  };
  const normalIncrement = () => {
    normalCount++;
    console.log(normalCount);
  };
  const normalDecrement = () => {
    normalCount--;
    console.log(normalCount);
  };

  return (
    <div>
      <h1> count : {count} </h1>
      <button onClick={increment}>더하기</button>
      <button onClick={decrement}>빼기</button>
      <button onClick={refIncrement}>ref더하기</button>
      <button onClick={refDecrement}>ref빼기</button>
      <button onClick={normalIncrement}>normalCount더하기</button>
      <button onClick={normalDecrement}>normalCount빼기</button>
    </div>
  );
};

// const Count = () => {
//   let count = 0;

//   const increment = () => {
//     count++;
//     console.log(count);
//   };
//   const decrement = () => {
//     count--;
//     console.log(count);
//   };
//   return (
//     <div>
//       <h1> count : {count} </h1>
//       <button onClick={increment}>더하기</button>
//       <button onClick={decrement}>빼기</button>
//     </div>
//   );
// };

export default Count;

// useRef
// 일반 js 변수와 같은 성격 , 값을 유지 하지 않은 => 값만 유지
// useState와 같은 성격, 랜더링, 값을 유지 => 랜더링 없이 값만 유지
// const input = document.querySelector('선택자')
