import React, { useRef, useContext } from "react";
import { SelectContext } from "./SelectContext";

const Select = () => {
  const { select, setSelect } = useContext(SelectContext);
  const selectRef = useRef();

  const handleChange = () => {
    // alert(selectRef.current.value);
    setSelect(selectRef.current.value);
  };

  return (
    <div>
      <h2>좋아하는 과일을 선택하세요.</h2>
      <select onChange={handleChange} ref={selectRef}>
        <option>선택하기</option>
        <option>오렌지</option>
        <option>사과</option>
        <option>바나나</option>
      </select>
    </div>
  );
};

export default Select;
