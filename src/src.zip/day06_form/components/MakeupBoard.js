import React, { useState, useEffect } from "react";
// React fetch를 사용하지만 then을 생략할 수 있는 fetch 라이브러리
// axios 를 사용해서 작업
// useEffect : 렌더링 된 후 처리할 일들을 정의해 두는 hook
// useEffect(()=>{}) ; 맨처음 랜더링될때, 랜더링 될때마다
// useEffect(()=>{}, [디펜던시어레이]) ; state
// useEffect(()=>{}, []) ; 맨처음 랜더링될때 , 초기화 해야 하는 값

const MakeupBoard = () => {
  const URL = `http://makeup-api.herokuapp.com/api/v1/products.json?brand=maybelline`;
  const [markup, setMakeup] = useState([]);

  const handleFetch = () => {
    fetch(URL)
      .then((res) => res.json())
      .then((res) => {
        console.log(res);
        setMakeup(res);
      });
  };

  useEffect(() => {
    handleFetch();
    // fetch : API 읽어올때, 데이터베이스랑 연동
    // 이베트를 언마운트시킬때
    // 컴포넌트 작업 후 state를 갱신할때
  });

  return (
    <div>
      {markup.map((item) => (
        <>
          <div>{item.name}</div>
          <img src={item.image_link} />
        </>
      ))}
    </div>
  );
};

export default MakeupBoard;
