import React, { useState } from "react";

const SubApp = () => {
  const [isDark, setIsDark] = useState(false);
  return (
    <div>
      <Page isDark={isDark} setIsDark={setIsDark} />
    </div>
  );
};

const Page = ({ isDark, setIsDark }) => {
  return (
    <div className="container">
      <Header isDark={isDark} setIsDark={setIsDark} />
      <Section isDark={isDark} />
      <Footer isDark={isDark} />
    </div>
  );
};

const Header = ({ isDark, setIsDark }) => {
  return (
    <header>
      <h1>Header</h1>
      <button onClick={() => setIsDark((prev) => !prev)}>darkmode</button>
      {/* <button onClick={() => setIsDark(!isDark)}>darkmode</button> */}
    </header>
  );
};
const Section = ({ isDark }) => {
  return <section>Section</section>;
};
const Footer = ({ isDark }) => {
  return <footer>Footer</footer>;
};

export default SubApp;
