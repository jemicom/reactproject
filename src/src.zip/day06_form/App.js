import React, { useState } from "react";
import Register from "./components/Register";
import Count from "./components/Count";
import Login from "./components/Login";
import SubApp from "./components/SubApp";
import Select from "./components/Select";
import { SelectContext } from "./components/SelectContext";
import MakeupBoard from "./components/MakeupBoard";

const App = () => {
  const [select, setSelect] = useState("");
  return (
    <SelectContext.Provider value={{ select, setSelect }}>
      <div>
        <MakeupBoard />
        {/* <Register /> */}
        {/* <Count /> */}
        {/* <Login /> */}
        {/* <SubApp /> */}
        {/* <Select /> */}
      </div>
    </SelectContext.Provider>
  );
};

export default App;
