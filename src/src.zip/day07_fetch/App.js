import React, { useState } from "react";
// import Count from "./components/Count";
import MakeupFetch from "./components/MakeupFetch";
// import FetchDatas from "./components/FetchDatas";
import Board from "./components/Board";
import NewPost from "./components/NewPost";
import MyFetch from "./components/MyFetch";

// cors : npm i cors 
// 같은 origin 데이터를 공유
//http://localhost:3000/
//http://localhost:3000/datas
//http://localhost:3000/res
//http://localhost:3000/hello/react

const App = () => {
  const [post, setPost] = useState({
    id: 1,
    title: "",
    content: "",
    date: new Date().getFullYear(),
  });

  const [posts, setPosts] = useState([
    {
      id: 1,
      title: "리엑트",
      content: "컴포넌트라는 작은 구조로 html 만들어 두어 재사용성을 높인 언어",
      date: new Date().getFullYear(),
    },
  ]);

  return (
    <div>
      <MyFetch />
      {/* <MakeupFetch /> */}
      {/* <FetchDatas /> */}
      {/* <NewPost
        post={post}
        setPost={setPost}
        setPosts={setPosts}
        length={posts.length}
      />
      <Board posts={posts} /> */}
    </div>
  );
};

export default App;
