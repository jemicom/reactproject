import React, { useEffect, useState } from "react";
import datas from "../datas/makeup.js";
// js 변수를 불러옴

const MakeupFetch = () => {
  //   const URL = `http://makeup-api.herokuapp.com/api/v1/products.json`;
  // const URL = `../datas/makeup.js`;

  const [makeup, setMakeup] = useState([]);
  // const fetchHandle = async () => {
  //   const res = await fetch(URL);
  //   const json = await res.json();
  //   setMakeup(json);
  // };

  useEffect(() => {
    // fetchHandle();
    console.log("makeup init");
    setMakeup(datas);
  }, []);

  //   const makeupComp = makeup.map((item) => (
  //     <div>
  //       <span>{item.id}</span>
  //       <span>{item.brand}</span>
  //       <span>{item.name}</span>
  //       <span>{item.category}</span>
  //     </div>
  //   ));

  return (
    <div>
      {makeup.length > 0 &&
        makeup.map((item) => (
          <div key={item.id}>
            <span>{item.id}</span>
            <span>{item.brand}</span>
            <span>{item.name}</span>
            <span>{item.category}</span>
          </div>
        ))}
    </div>
  );
};

export default MakeupFetch;
