import React, { useEffect, useState } from "react";

const Count = () => {
  const [count, setCount] = useState(0);
  const [term, setTerm] = useState("");

  useEffect(() => {
    console.log("랜더링");
    // 화면 갱신 후 처리할 어떤 작업
    // 입력등을 사용할 때는 과부하
  });

  useEffect(() => {
    console.log("count 변경될때 랜더링");
  }, [count]); // 의존성배열

  useEffect(() => {
    console.log("빈배열 랜더링");
  }, []); // 의존성배열이 빈 배열이면 맨처음 한번만 실행
  // 마운트 될때

  const forHandle = () => {
    let sum = 0;
    for (let a = 0; a < 10000; a++) {
      sum += a;
    }
    setCount(sum);
  };

  return (
    <div>
      <div>
        <p>count : {count}</p>
        <button onClick={() => setCount((prev) => prev + 1)}>증가</button>
        <button onClick={() => setCount((prev) => prev - 1)}>감소</button>
      </div>
      <div>
        <p>count : {count}</p>
        <button onClick={forHandle}>증가</button>
      </div>
      <div>
        <label>{term}</label>
        <input type="text" onChange={(e) => setTerm(e.target.value)} />
      </div>
    </div>
  );
};

export default Count;
