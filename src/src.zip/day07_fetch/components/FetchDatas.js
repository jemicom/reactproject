import React from "react";
import datas from "../datas/movie";

const FetchDatas = () => {
  return <div>{datas.length}</div>;
};

export default FetchDatas;
