import React from "react";

const style = {
  display: "flex",
  lineHeight: "10px",
  gap: "0",
};

const Board = ({ posts }) => {
  const returnPosts = posts.map((post) => (
    <div style={style}>
      <p>{post.id}</p>
      <p>{post.title}</p>
      <p>{post.content}</p>
      <p>{post.date}</p>
    </div>
  ));

  return <div>{returnPosts}</div>;
};

export default Board;
