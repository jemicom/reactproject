import React, { useEffect, useState } from "react";
// https://axios-http.com/kr/docs/example

const MyFetch = () => {
  const url = "http://localhost:3500/datas";

  const [movies, setMovies] = useState([]);

  const fetchHandle = async () => {
    const res = await fetch(url);
    const json = await res.json();
    setMovies(json.data.movies);
  };

  useEffect(() => {
    fetchHandle();
  }, []);

  return (
    <div>
      {movies.map((movie) => (
        <div key={movie.id}>{movie.title}</div>
      ))}
    </div>
  );
};

export default MyFetch;
