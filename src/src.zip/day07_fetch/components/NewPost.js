import React from "react";
const style = {
  display: "flex",
  flexDirection: "column",
  gap: "10px",
  width: "300px",
};

const NewPost = ({ post, setPost, setPosts, length }) => {
  const submitHandle = (event) => {
    event.preventDefault();
    const newPost = { ...post, id: length + 1 };
    setPosts((prev) => [...prev, newPost]);

    setPost((prev) => ({ ...prev, title: "", content: "" }));
  };

  return (
    <div>
      <form style={style} onSubmit={submitHandle}>
        <label htmlFor="title">제목</label>
        <input
          type="text"
          id="title"
          onChange={(e) =>
            setPost((prev) => ({ ...prev, title: e.target.value }))
          }
          //   post.title = e.target.value
          value={post.title}
        />
        <label htmlFor="content">내용</label>
        <input
          type="text"
          id="content"
          value={post.content}
          onChange={(e) =>
            setPost((prev) => ({ ...prev, content: e.target.value }))
          }
        />
        <button>등록</button>
      </form>
    </div>
  );
};

export default NewPost;
