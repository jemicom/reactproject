import React, { useState } from "react";

const ConditionHello = () => {
  const [logIn, setLogin] = useState(true);
  return logIn && <div> Hello 홍길동 </div>;

  // 피연산자 && 피연산자 : 뒤의 값 사용하기 위함
  // 피연산자 || 피연산자 : 앞의 값 사용하기 위함
  //   return logIn ? <div> Hello 홍길동 </div> : <div> login 하세요</div>;
  //   {
  //     if (logIn) <div> login </div>;
  //     else <div> Hello 홍길동 </div>;
  //   }
};

export default ConditionHello;
