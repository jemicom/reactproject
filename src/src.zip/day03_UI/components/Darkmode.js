import React from "react";

const Darkmode = ({ darkMode, setDarkMode }) => {
  return (
    <button onClick={() => setDarkMode(!darkMode)}>
      {/* {darkMode ? "블랙" : "화이트"} */}
      {darkMode ? "darkmode" : "normal"}
    </button>
  );
};

export default Darkmode;
