import React from "react";

const List = () => {
  const todoList = [
    { task: "빨래하기", finished: false },
    { task: "공부하기", finished: true },
  ];
  //   return (
  //     <div>
  //       <div>{todoList[0].task}</div>
  //       <div>{todoList[1].task}</div>
  //     </div>
  //   );

  //   return (
  //     <div>
  //       {todoList.map((todo) => (
  //         <div>{todo.task}</div>
  //       ))}
  //     </div>
  //   );

  const todos = todoList.map((todo) => <div key={todo.task}>{todo.task}</div>);
  console.log(todos);

  const compAry = [<Hello />, <Greet />, <Javascript />];
  return (
    <div>
      {todos}
      {compAry}
    </div>
  );
};

// 내부 컴포넌트
const Hello = () => {
  return <div>Hello</div>;
};
const Greet = () => {
  return <div>Greet</div>;
};
const Javascript = () => {
  return <div>Javascript</div>;
};

export default List;
