import React from "react";

const JsArray = () => {
  const qs = "nanana=100&apple=20&orange=300";
  const chunks = qs.split("&");
  console.log(chunks); // ['nanana=100', 'apple=20', 'orange=300']

  let result = {};
  //   for (let i = 0; i < chunks.length; i++) {
  //     let parts = chunks[i].split("=");
  //     console.log(parts);
  //     let key = parts[0];
  //     result[key] = parts[1];
  //     console.log(result);
  //   }

  //   chunks.forEach((chunk) => {
  //     const [key, value] = chunk.split("="); // [ "banana" , 100]
  //     result[key] = value;
  //   });

  const returnValue = chunks
    .map((chunk) => chunk.split("="))
    .map(([key, value]) => ({
      key,
      value,
    }));
  // .reduce((result, [key, value]) => ({ ...result, [key]: value }), {});
  return <div>{JSON.stringify(returnValue)}</div>;
};

export default JsArray;
