import React from "react";

// const Lnb = () => {
//   const menu = [ "사과" , "바나나" , "딸기"  , "오렌지"  ];
//   return (
//     <div>
//       {menu.map((item, index) => (
//         <div key={index}>
//           {index}
//           {item}
//         </div>
//       ))}
//     </div>
//   );
// };

const Lnb = () => {
  const menu = [
    { id: 1, fruit: "사과" },
    { id: 2, fruit: "바나나" },
    { id: 3, fruit: "딸기" },
    { id: 4, fruit: "오렌지" },
  ];
  return (
    <div>
      {menu.map((item, index) => (
        <div key={item.id}>
          {item.id}
          {item.fruit}
        </div>
      ))}
    </div>
  );
};

// React의 화면 갱신은 변경된 부분만 갱신
// 유일한 값, index를 사용하지 않는다.
// keyprops 값은 중복되도 문제 발생
// 데이터 중 유일한 값으로 존재하는 데이터를 사용한다.

export default Lnb;
