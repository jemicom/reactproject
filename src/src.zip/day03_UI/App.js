import React, { useState } from "react";
import JsArray from "./components/JsArray";
import ConditionHello from "./components/ConditionHello";
import List from "./components/List";
import Lnb from "./components/Lnb";
import Tabs from "./components/Tabs";
import Darkmode from "./components/Darkmode";

const darkModeStyle = {
  background: "black",
  color: "white",
};
const normalModeStyle = {
  background: "white",
  color: "black",
};

const App = () => {
  const tabsDatas = [
    {
      id: 1,
      title: "btn1",
      content: "한글은 아름다운 글입니다.",
    },
    {
      id: 2,
      title: "btn2",
      content:
        "React를 사용하는데 관심이 있다면, 온라인 코드 편집기를 사용할 수 있습니다. CodePen, CodeSandbox 또는 Stackblitz에서 Hello World 템플릿을 사용해 보세요.",
    },
    {
      id: 3,
      title: "btn3",
      content:
        "1분 안에 HTML 페이지에 React를 추가할 수 있습니다. 그리고 조금씩 React의 비중을 늘리거나 몇 개의 동적 위젯에 포함할 수 있습니다.",
    },
    {
      id: 4,
      title: "btn1",
      content: "한글은 아름다운 글입니다.",
    },
    {
      id: 5,
      title: "btn2",
      content:
        "React를 사용하는데 관심이 있다면, 온라인 코드 편집기를 사용할 수 있습니다. CodePen, CodeSandbox 또는 Stackblitz에서 Hello World 템플릿을 사용해 보세요.",
    },
    {
      id: 6,
      title: "btn3",
      content:
        "1분 안에 HTML 페이지에 React를 추가할 수 있습니다. 그리고 조금씩 React의 비중을 늘리거나 몇 개의 동적 위젯에 포함할 수 있습니다.",
    },
  ];

  const [darkMode, setDarkMode] = useState(false);
  return (
    <div style={darkMode ? darkModeStyle : normalModeStyle}>
      <Darkmode darkMode={darkMode} setDarkMode={setDarkMode} />
      {/* <JsArray /> */}
      {/* <ConditionHello /> */}
      {/* <List /> */}
      {/* <Lnb /> */}
      <Tabs tabsDatas={tabsDatas} />
    </div>
  );
};

export default App;
