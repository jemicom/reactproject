import React from "react";
import MyStateAry from "./components/MyStateAry";
import Count from "./components/Count";
import Input from "./components/Input";
import Html from "./components/Html";

const App = () => {
  return (
    <div>
      <Input />
      {/* <MyStateAry />
      <Count /> */}
    </div>
  );
};

export default App;
