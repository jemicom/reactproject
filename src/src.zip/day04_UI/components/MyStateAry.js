import React, { useState } from "react";

const MyStateAry = () => {
  const [todos, setTodos] = useState([]);
  // []
  // [hi]
  // [hi, hi]

  const normalAry = [];
  normalAry.push("hello");
  normalAry.push("React");
  console.log(normalAry);

  const addHandle = () => {
    // todos.push("hi");

    setTodos([...todos, "hi"]);
    // setTodos((prevState) => {
    //   console.log(prevState);
    //   //   return [...todos, "hi"];
    //   return [...prevState, "hi"];
    // });
    console.log(todos);
  };

  return (
    <div>
      <button onClick={addHandle}>add</button>
    </div>
  );
};

export default MyStateAry;
