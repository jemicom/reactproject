import React, { useState } from "react";

const Count = () => {
  const [count, setCount] = useState(0);
  let num = 0;
  num++;

  const addHandle = () => {
    setCount(count + 1);
    // count++; //사용하지 않음
    // setCount((prev) => {
    //   console.log("prev", prev);
    //   return prev + 1;
    // });
    console.log("count", count);
  };

  return (
    <div>
      <button onClick={addHandle}>Count</button>
    </div>
  );
};

export default Count;
