import React, { useState } from "react";

const Input = () => {
  const [todo, setTodo] = useState("");
  const [todos, setTodos] = useState(["html", "css"]);

  const onChangeHandle = (event) => {
    // console.log(event.target.value);
    // state, props 값들을 확인하기 위한 개발 툴
    // 브라우저 : react dev tool 설치
    setTodo(event.target.value);
  };

  const onClickHandle = () => {
    setTodos([todo, ...todos]);
    // console.log(todos);
    const inputTodo = document.querySelector("#todo");
    inputTodo.value = "";
  };

  return (
    <div>
      <input
        id="todo"
        type="text"
        onChange={onChangeHandle}
        placeholder="문자열을 입력하세요"
      />
      <button onClick={onClickHandle}>추가</button>
      <ul>
        {!!todos.length &&
          todos.map((todo, index) => (
            <li key={index}>
              {index}
              {todo}
            </li>
          ))}
        {/* 
            keyprops : 각각의 요소를 구분하기 위한 속성
            유일한 값, 중복된 값을 사용하면 안됨 
            index : 유일한 값처럼 보이지만 구분값이 순차적으로 입력되면서 바뀐다 오류발생
        */}
      </ul>
    </div>
  );
};

export default Input;
