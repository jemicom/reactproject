import React, { useState } from "react";
import todoStyle from "./Input.module.css";
import { AiFillDelete } from "react-icons/ai";
import { FaCheckCircle } from "react-icons/fa";
import { MdOutlineRadioButtonChecked } from "react-icons/md";

// https://react-icons.github.io/react-icons/
// npm i react-icons

const Input = () => {
  const [todo, setTodo] = useState("");
  const [todos, setTodos] = useState([
    { id: 0, item: "html", checked: true },
    { id: 1, item: "css", checked: true },
    { id: 2, item: "javascript", checked: false },
    { id: 3, item: "node", checked: false },
  ]);

  const onChangeHandle = (event) => {
    // console.log(event.target.value);
    // state, props 값들을 확인하기 위한 개발 툴
    // 브라우저 : react dev tool 설치
    setTodo(event.target.value);
  };

  const onClickHandle = () => {
    const item = {
      // id: todos[todos.length - 1].id + 1,
      id: todos.length,
      item: todo,
      checked: false,
    };
    setTodos([item, ...todos]); // 전개연산자
    // console.log(todos);
    // todos.push();

    const inputTodo = document.querySelector("#todo");
    inputTodo.value = "";
    // javascript type => react type
  };

  const onCheckedHandle = (id) => {
    // console.log(id);
    // const findTodo = todos.find((todo) => todo.id === id);

    // console.log(findTodo);
    // // const changeTodo = {
    // //   id: findTodo.id,
    // //   item: findTodo.item,
    // //   checked: !findTodo.checked
    // // };

    // const changeTodo = { ...findTodo, checked: !findTodo.checked };
    // console.log(changeTodo);

    const checkedTodos = todos.map((todo) =>
      todo.id === id ? { ...todo, checked: !todo.checked } : todo
    );
    setTodos(checkedTodos);
  };

  // splice 배열함수를 이용한 방법
  const deleteHandle = (id) => {
    const backTodos = [...todos];
    const findTodo = backTodos.find((todo) => todo.id === id);
    const indexNum = backTodos.indexOf(findTodo);
    console.log(indexNum);
    backTodos.splice(indexNum, 1); // 자신의 배열 삭제
    // return : 지운값을 리턴
    setTodos(backTodos);
  };

  // filter를 이용한 방법
  // const deleteHandle = (id) => {
  //   const filterTodo = todos.filter((todo) => todo.id !== id);
  //   setTodos(filterTodo);
  // };

  return (
    <div>
      <input
        id="todo"
        type="text"
        onChange={onChangeHandle}
        placeholder="문자열을 입력하세요"
      />
      <button onClick={onClickHandle}>추가</button>
      <ul className={todoStyle.ul}>
        <li>
          <span>번호</span>
          <span>할일</span>
          <span>체크</span>
          <span></span>
        </li>
        {!!todos.length &&
          todos.map((todo, index) => (
            <li key={todo.id}>
              <span>{todo.id}</span>
              <label
                htmlFor={`checked_${todo.id}`}
                style={{
                  textDecoration: todo.checked ? "line-through" : "none",
                }}
              >
                {todo.item}
              </label>
              {/* <input
                type="checkbox"
                id={`checked_${todo.id}`}
                checked={todo.checked ? "checked" : ""}
                onChange={() => onCheckedHandle(todo.id)}
              /> */}
              <div
                type="checkbox"
                id={`checked_${todo.id}`}
                checked={todo.checked ? "checked" : ""}
                onChange={() => onCheckedHandle(todo.id)}
                // 오류
              >
                {todo.checked ? (
                  <FaCheckCircle />
                ) : (
                  <MdOutlineRadioButtonChecked />
                )}
              </div>

              {/* <FaCheckCircle
                type="checkbox"
                id={`checked_${todo.id}`}
                checked={todo.checked ? "checked" : ""}
                onChange={() => onCheckedHandle(todo.id)}
              /> */}
              {/* <button onClick={() => deleteHandle(todo.id)}>del</button> */}
              <AiFillDelete onClick={() => deleteHandle(todo.id)} />
            </li>
          ))}
        {/* 
          input 
          for => htmlFor 변경
        */}
      </ul>
    </div>
  );
};

export default Input;
