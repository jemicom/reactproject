import React from "react";

const Html = () => {
  return (
    <ul>
      <li>
        <label htmlFor="box01">html</label>
        <input type="checkbox" id="box01" checked="checked" />
      </li>
      <li>
        <label htmlFor="box02">html</label>
        <input type="checkbox" id="box02" />
      </li>
      <li>
        <label htmlFor="box03">html</label>
        <input type="checkbox" id="box03" />
      </li>
      <li>
        <label htmlFor="box04">html</label>
        <input type="checkbox" id="box04" />
      </li>
    </ul>
  );
};

export default Html;
