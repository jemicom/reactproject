import "./Header.css";
import logo from "../logo.svg";

const Header = (props) => {
  // props { brand : "React JSX"}
  // console.log(JSON.stringify(props));
  return (
    <header className="header">
      <h1>
        <img src={logo} alt="" className="logo" />
        {props.brand}
      </h1>
    </header>
  );
};

export default Header;
