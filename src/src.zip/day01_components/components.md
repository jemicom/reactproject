```
npx create-react-app my-app
cd my-app
npm start
```

# 코드 스닛핏 설치

ES7+ React/Redux/React-Native snippets

# HMR(Hot Module Replace)

node 노드몬, 또는 --watch, 라이브 서버 같은 기능
브라우저를 리로드 하지 않아도 모듈을 바꿔주는 기능

jsx 컴포넌트 타입 : 클래스형 컴포넌트, 함수형 컴포넌트 + hook

# react 변수 3가지(상태관리자)

props : 상위컴포넌트에서 하위컴포넌트에 데이터를 전달할때
state : 컴포넌트 내에서 사용하는 데이터, state 값이 바뀌면 화면이 갱신됨
context : 최상위 컴포넌트에서 어디서나 사용하도록 공유하는 변수

# React & Javascript + HTML 차이점

파일명(함수명:클래스명) 첫글자 대문자 : 컴포넌트 이름으로 사용하기 위함
함수 반드시 한개만 리턴 : fragment 로 감싸기
return () 소괄호 : 태그를 리턴한다는 의미
{} 중괄호 : javascript 코드를 사용할때
리엑트 태그의 class 선언은 className으로 바꾸어 사용한다.

# 코드 스닛핏 설명

## 함수형 컴포넌트

1. rafc
1. rafce
1. rafcp
1. rcc
1. rcce
1. rcep

1. rafc

```
import React from 'react'

export const Footer = () => {
    return (

        <div>Footer</div>
    )
}
```

import "./Footer.css";
// 2. rafce
import React from "react";

const Footer = () => {
return <footer>Footer</footer>;
// 클래스 대신 태그 사용했으니 className 속성 사용하지 않음
};

export default Footer;

3. rafcp
   import React from 'react'
   import PropTypes from 'prop-types'

const Footer = props => {
return (

<div>Footer</div>
)
}

Footer.propTypes = {}

export default Footer

4. rfc
   import React from 'react'

export default function Footer() {
return (

<div>Footer</div>
)
}

5. rfce
   import React from 'react'

function Footer() {
return (

<div>Footer</div>
)
}

export default Footer

6. rfcp
   import React from 'react'
   import PropTypes from 'prop-types'

function Footer(props) {
return (

<div>Footer</div>
)
}

Footer.propTypes = {}

export default Footer
