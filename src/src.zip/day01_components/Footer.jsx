import "./Footer.css";

import React from "react";

const Footer = () => {
  return <footer>Footer</footer>;
  // 클래스 대신 태그 사용했으니 className 속성 사용하지 않음
};

export default Footer;
