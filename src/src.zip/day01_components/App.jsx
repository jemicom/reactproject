import React from "react";
// day01_components
import Header from "./Header";
import Section from "./Section";
import Footer from "./Footer";
import "./App.css";

const App = () => {
  return (
    <div className="app__container">
      <Header brand="React JSX" />
      <Section />
      <Footer />
      {/* <div></div> */}
    </div>
  );
};

export default App;

