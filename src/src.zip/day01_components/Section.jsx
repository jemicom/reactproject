import "./Section.css";
import React from "react";
import { useState } from "react";

const Section = () => {
  const [num, setNum] = useState(0);
  // const num = 0;

  return (
    <section className="section">
      num = {num}
      <br />
      Lorem ipsum, dolor sit amet consectetur adipisicing elit. Aut adipisci
      vero beatae dicta tempora tenetur ipsam fuga neque eaque delectus magni
      quae perspiciatis esse corrupti praesentium, nemo iure ad aliquam.
    </section>
  );
};

export default Section;
