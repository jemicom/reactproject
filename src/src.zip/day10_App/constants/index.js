import img1 from "../assets/img_banner1_1.jpg";
import img2 from "../assets/img_banner1_2.jpg";
import img3 from "../assets/img_banner1_3.jpg";
import img4 from "../assets/img_banner1_4.jpg";

const banners = [img1, img2, img3, img4];
export default banners;
