# 이벤트 핸들러

onClick
onSubmit
onChange

onClick={핸들러처리}
onSubmit={핸들러처리}
onChange={핸들러처리}

onClick={()=>핸들러처리(param)}
onSubmit={()=>핸들러처리(param)}
onChange={()=>핸들러처리(param)}

# 은행계좌관리

# 출석부
<form>
이름 입력받고 목록 등록 <input>
출석여부 표현 : 취소선
useRef

const userName = document.querySelector("#userName);
$("#userName")
const userNameRef = useRef();

# login

# 회원가입
