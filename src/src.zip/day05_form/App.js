import React, { useState } from "react";
import Attendence from "./components/Attendence";
import Login from "./components/Login";

const App = () => {
  const [user, setUser] = useState("");
  //const loginUser = {  username,  userpwd };

  return (
    <div>
      {user ? null : <Login user={user} setUser={setUser} />}
      {user ? <Attendence /> : null}
      {user ? <button onClick={() => setUser("")}>로그아웃</button> : null}
    </div>
  );
};

export default App;
