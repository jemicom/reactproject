import React, { useState } from "react";
import AttenRows from "./AttenRows";
import InputForm from "./InputForm";

const users = [
  {
    id: 1,
    name: "홍길동",
    isChecked: false,
  },
  {
    id: 2,
    name: "남길동",
    isChecked: false,
  },
  {
    id: 3,
    name: "박은지",
    isChecked: true,
  },
];

const Attendence = () => {
  const [name, setName] = useState("");
  const [names, setNames] = useState(users); // 배열로 초기화

  const changeHandle = (event) => setName(event.target.value);
  const addHandle = (event) => {
    event.preventDefault();

    const ids = names.map((name) => name.id);
    console.log(ids); // 배열

    const newName = {
      id: names.length ? Math.max(...ids) + 1 : 1,
      // id: names.length ? Math.max(1,2,3) : 1,
      name,
      isChecked: false,
    };

    setNames([...names, newName]); // 중요
    setName("");
  };

  const deleteHandle = (id) => {
    // id = name.id
    console.log(id);

    const deleteNames = names.filter((name) => name.id !== id);
    setNames(deleteNames);
  };

  const isCheckedHandle = (id) => {
    console.log(id);
    const updateNames = names.map((name) =>
      name.id === id ? { ...name, isChecked: !name.isChecked } : name
    );

    //console.log(updateNames); //
    setNames(updateNames);
  };
  return (
    <>
      <InputForm
        addHandle={addHandle}
        changeHandle={changeHandle}
        name={name}
      />
      <div className="names_list">
        {names.length > 0 &&
          names.map((name) => (
            //   props driling
            <AttenRows
              key={name.id}
              name={name}
              isCheckedHandle={isCheckedHandle}
              deleteHandle={deleteHandle}
            />
          ))}
      </div>
    </>
  );
};

export default Attendence;
