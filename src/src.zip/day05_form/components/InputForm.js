import React from "react";

const InputForm = ({ addHandle, changeHandle, name }) => {
  // 배열 : 순서상관 있고
  // 객체 : 순서상관 없고

  return (
    <form onSubmit={addHandle}>
      <input
        type="text"
        placeholder="출석자이름을 입력"
        onChange={changeHandle}
        value={name}
      />
      <button>추가</button>
    </form>
  );
};

export default InputForm;
