import React, { useState } from "react";

const Login = ({ user, setUser }) => {
  const [name, setName] = useState("");
  const [pwd, setPwd] = useState("");

  const loginHandle = () => {
    const loginUser = {
      username: name,
      userpwd: pwd,
    };
    console.log(loginUser);
    setUser(loginUser);
  };

  return (
    <div className="loginForm">
      <div>
        <label htmlFor="userid"> 아이디 </label>
        <input
          type="text"
          id="userid"
          onChange={(e) => setName(e.target.value)}
        />
      </div>
      <div>
        <label htmlFor="userpwd"> 비밀번호 </label>
        <input
          type="text"
          id="userpwd"
          onChange={(e) => setPwd(e.target.value)}
        />
      </div>
      <button onClick={loginHandle}>로그인</button>
    </div>
  );
};

export default Login;

// router
