import React from "react";
import { FaTimesCircle, FaCheckCircle } from "react-icons/fa";

/*
// name = { id, isChecked, name} 객체 구조가 아닌 데이터를 전송해서 처리할 수 없음
// 좋은 컴포넌트는 아님
// const IsChecked = (props) => {
//     const { name } = props;
const IsChecked = ({ name, isCheckedHandle }) => {
  return (
    <>
      {name.isChecked ? (
        <FaCheckCircle
          onClick={() => isCheckedHandle(name.id)}
          style={{ color: "blue" }}
        />
      ) : (
        <FaTimesCircle
          onClick={() => isCheckedHandle(name.id)}
          style={{ color: "red" }}
        />
      )}
    </>
  );
};
*/
const IsChecked = ({ isChecked, id, isCheckedHandle }) => {
  return (
    <>
      {isChecked ? (
        <FaCheckCircle
          onClick={() => isCheckedHandle(id)}
          style={{ color: "blue" }}
        />
      ) : (
        <FaTimesCircle
          onClick={() => isCheckedHandle(id)}
          style={{ color: "red" }}
        />
      )}
    </>
  );
};

export default IsChecked;
