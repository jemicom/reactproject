import React from "react";
import { RiDeleteBin2Fill } from "react-icons/ri";
import attStyle from "./AttenRows.module.css";
import IsChecked from "./IsChecked";

const AttenRows = ({ name, isCheckedHandle, deleteHandle }) => {
  return (
    <div className={attStyle.rows}>
      <span>{name.id}</span>
      <span>{name.name}</span>
      <span>
        {/* <IsChecked name={name} isCheckedHandle={isCheckedHandle} /> */}
        <IsChecked
          isChecked={name.isChecked}
          id={name.id}
          isCheckedHandle={isCheckedHandle}
        />
      </span>

      <RiDeleteBin2Fill onClick={() => deleteHandle(name.id)} />
    </div>
  );
};

export default AttenRows;

{
  /* <FaCheckCircle
      onClick={() => isCheckedHandle(name.id)}
      style={{ display: name.isChecked ? "block" : "none" }}
    />
    <FaTimesCircle
      onClick={() => isCheckedHandle(name.id)}
      style={{ display: name.isChecked ? "none" : "block" }}
    /> */
}
