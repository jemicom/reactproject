# style 사용법

1. inline

```
<div style={{color:"red"}}>
const style={color:"red"};
<div style={style}>
```

2. style.css : 하위 컴포넌트에 영향을 미칠 수 있다.
   html,css 방법
   상위컴포넌트에서 지정한 디자인이 하위 컴포넌트에 영향을 미칠 수 있음

3. style.module.css : js 타입으로 사용하기, 모듈 방법
   import style from "./style.module.css"
   <div className={style.lnb}>
   상위 컴포넌트의 디자인과 하위 컴포넌트의 디자인의 겹침 현상 사라짐

4. 프레임워크 라이브러리

5. Sass, less

# event 사용법

1. 파라미터를 전달하는 이벤트 핸들러
   const btnHandler = (event, num) =>{}
2. 파라미터를 전달하지 않은 이벤트 핸들러
   const btnHandler = () =>{}

# React & Javascript + HTML 차이점

파일명(함수명:클래스명) 첫글자 대문자 : 컴포넌트 이름으로 사용하기 위함
함수 반드시 한개만 리턴 : fragment 로 감싸기
return () 소괄호 : 태그를 리턴한다는 의미
{} 중괄호 : javascript 코드를 사용할때
리엑트 태그의 class 선언은 className으로 바꾸어 사용한다.
이벤트 핸들러 onclick => onClick 카멜 케이스 사용
