import React from "react";
import Nav from "./components/Nav";
import "./App.css";
import Button_Red from "./components/Button_Red";
import Button_blue from "./components/Button_blue";
import Header from "./components/Header";
import Button from "./components/Button";
import Count from "./components/Count";
import Tabs from "./components/Tabs";

const App = () => {
  return (
    <div>
      <Tabs />
      <Count />
      <Count />
      <Count />
      <Count />
      <Button>더하기</Button>
      <Button>빼기</Button>
      <Button>곱하기</Button>
      {/* <Header
        brand="koreaIT"
        age={5}
        bool={true}
        name={"홍길동"}
        ary={["a", "b", "c"]}
        obj={{ firstName: "hong", lastName: "gildong" }}
      />
      <Nav />
      <Button_Red />
      <Button_blue />

      <Button> 열고 닫고 태그 </Button>
      <Button />
      <Button>
        <a>한글</a>
        <a>아름</a>
        <a>다운</a>
      </Button> */}
    </div>
  );
};

export default App;
