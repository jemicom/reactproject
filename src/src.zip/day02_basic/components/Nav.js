import React from "react";
import "./Nav.css";
// 원래 사용하던 디자인 방식

const Nav = () => {
  return (
    <nav className="lnb">
      <ul>
        <li>
          <a href="#">정보공개</a>
        </li>
        <li>
          <a href="#">민원</a>
        </li>
        <li>
          <a href="#">참여</a>
        </li>
        <li>
          <a href="#">정보</a>
        </li>
        <li>
          <a href="#">알림</a>
        </li>
        <li>
          <a href="#">소개</a>
        </li>
      </ul>
    </nav>
  );
};

export default Nav;
