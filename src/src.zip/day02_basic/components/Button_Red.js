import React from "react";


const Button_Red = () => {
  return (
    <button
      onClick={() => {
        console.log("click");
      }}
      style={{
        backgroundColor: "red",
        border: "none",
        padding: "10px",
      }}
    >
      Button_Red
    </button>
  );
};

export default Button_Red;
