import React, { useState } from "react";
import btn from "./Button.module.css";

const Button = (props) => {
  const [condition, setCondition] = useState(false);
  // condition = true;

  const toggleCondition = () => {
    setCondition(!condition);
  };
  return (
    <div className={condition ? btn.btn : ""} onClick={toggleCondition}>
      {props.children}
    </div>
  );
};

export default Button;
