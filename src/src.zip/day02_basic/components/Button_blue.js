import React from "react";
import blue from "./Button_blue.module.css";

const Button_blue = () => {
  const clickHandle = () => {
    console.log("blue button click");
  };

  return (
    <button onClick={clickHandle} className={blue.blue}>
      Button_blue
    </button>
  );
};

export default Button_blue;
