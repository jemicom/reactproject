import React from "react";

/*
// getAttribute()
const Header = (props) => {
  console.log(props);
  const { brand, age, bool } = props;

  return (
    <header>
      Header {JSON.stringify(props)} {brand} {props.age}
      <p>{bool ? "true" : "false"}</p>
      <p>{props.ary.join(",")}</p>
      <p>{JSON.stringify(props.obj)}</p>
    </header>
  );
};
*/

// 전개연산자
const Header = ({ brand, age, ary, obj, name }) => {
  return (
    <header>
      <p>{brand}</p>
      <p>{age}</p>
      <p>{ary.join(" , ").toString()}</p>
      <p>{JSON.stringify(obj)}</p>
      <p>{name}</p>
    </header>
  );
};

export default Header;
