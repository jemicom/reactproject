import React, { useState } from "react";

const Tabs = () => {
  const [toggle, setToggle] = useState("btn3");
  const toggleHandle = (btnStr) => {
    setToggle(btnStr);
    console.log(toggle);
  };
  return (
    <div className="tabs">
      <ul className="btn">
        <li>
          <a
            href="#"
            onClick={() => {
              toggleHandle("btn1");
            }}
          >
            btn1
          </a>
        </li>
        <li>
          <a
            href="#"
            onClick={() => {
              toggleHandle("btn2");
            }}
          >
            btn2
          </a>
        </li>
        <li>
          <a
            href="#"
            onClick={() => {
              toggleHandle("btn3");
            }}
          >
            btn3
          </a>
        </li>
      </ul>
      <div className="panels">
        <div
          className="panel"
          style={{ display: toggle === "btn1" ? "block" : "none" }}
          //   style="display:none"
        >
          1 dolor sit amet consectetur adipisicing elit. Voluptas quasi
          voluptate pariatur assumenda nisi odit nihil fugit voluptates!
          Doloremque, veniam commodi reiciendis tempora molestias enim beatae
          nobis aliquid culpa temporibus!
        </div>
        <div
          className="panel"
          style={{ display: toggle === "btn2" ? "block" : "none" }}
        >
          2 Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit
          quis nemo sequi? Officiis facere suscipit, magni quia laborum
          architecto dolorum temporibus nostrum quod debitis pariatur. Libero
          quia excepturi deleniti iusto.
        </div>
        <div
          className="panel"
          style={{ display: toggle === "btn3" ? "block" : "none" }}
        >
          3 adipisicing elit. Consequatur omnis quasi dolorem odio rem ut neque
          expedita. Porro sunt laudantium, harum nam voluptatibus unde nisi,
          ipsam, expedita consequatur itaque magni!
        </div>
      </div>
    </div>
  );
};

export default Tabs;
