import React, { useState } from "react";

const Count = () => {
  const [count, setCount] = useState(0);
  // let count = 0;
  // Count 컴포넌트내의 상태를 관리

  const increment = () => {
    // count = count + 1;
    // console.log(count);
    // const h1 = document.querySelector("h1");
    // h1.innerHTML = `count : ${count}`;

    setCount(count + 1);
  };

  const decrement = () => {
    setCount(count - 1);
  };
  return (
    <div>
      <h1>count : {count}</h1>
      <button onClick={increment}> +1 add </button>
      <button onClick={decrement}> -1 sub </button>
    </div>
  );
};

export default Count;
